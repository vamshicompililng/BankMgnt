package Bank_mgmt.db;

import java.sql.*; 
import javax.swing.*;

public class DBConnection{
    public Connection c;
    public Statement s;
    public DBConnection(){  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost:3306/bankmanagementsystem","root","Varsha@123"); 
            s =c.createStatement(); 
           
          
            
        }catch(Exception e){ 
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "DB Connection Failed: "+ e.getMessage());
        }  
    }  
}  
