package Bank_mgmt.ui;

import Bank_mgmt.ui.Login;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Launcher extends JFrame implements ActionListener {
    JButton customerLoginBtn, employeeLoginBtn;

    public Launcher() {
        setTitle("Welcome to Indian Bank - Menu");
        setSize(600, 400);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel heading = new JLabel("WELCOME TO INDIAN BANK", JLabel.CENTER);
        heading.setFont(new Font("Osward", Font.BOLD, 32));
        heading.setBounds(50, 30, 500, 50);
        add(heading);

        JLabel subHeading = new JLabel("Menu Screen", JLabel.CENTER);
        subHeading.setFont(new Font("Raleway", Font.BOLD, 20));
        subHeading.setBounds(50, 90, 500, 30);
        add(subHeading);

        customerLoginBtn = new JButton("Login as Customer");
        customerLoginBtn.setBounds(200, 160, 200, 40);
        customerLoginBtn.addActionListener(this);
        add(customerLoginBtn);

        employeeLoginBtn = new JButton("Login as Employee");
        employeeLoginBtn.setBounds(200, 220, 200, 40);
        employeeLoginBtn.addActionListener(this);
        add(employeeLoginBtn);

        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == customerLoginBtn) {
            setVisible(false);
            new Login().setVisible(true);
        } else if (ae.getSource() == employeeLoginBtn) {
            setVisible(false);
            new EmployeeLogin().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Launcher();
    }
}
