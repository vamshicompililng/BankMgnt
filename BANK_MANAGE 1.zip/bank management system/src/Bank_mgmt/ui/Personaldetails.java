package Bank_mgmt.ui;

import Bank_mgmt.db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public class Personaldetails extends JFrame implements ActionListener {

    long random;
    JTextField nameTextField, fnameTextField, emailTextField, addressTextField, cityTextField, stateTextField, pincodeTextField;
    JDateChooser dateChooser;
    JRadioButton male, female, married, single, other;

    Personaldetails() {
        setLayout(null);
        setTitle("Signup Form");

        Random ran = new Random();
        random = Math.abs((ran.nextLong() % 9000L) + 1000L);

        JLabel formno = new JLabel("APPLICATION FORM NO: " + random);
        formno.setFont(new Font("Raleway", Font.BOLD, 18));
        formno.setBounds(40, 10, 600, 30);
        add(formno);

        JLabel personDetails = new JLabel("Page 1: Personal Details");
        personDetails.setFont(new Font("Raleway", Font.BOLD, 14));
        personDetails.setBounds(280, 40, 200, 30);
        add(personDetails);

        int labelX = 50, fieldX = 200, width = 200, height = 25, startY = 80, gap = 35;
        int y = startY;

        JLabel name = new JLabel("Name:");
        name.setBounds(labelX, y, 150, height);
        add(name);

        nameTextField = new JTextField();
        nameTextField.setBounds(fieldX, y, width, height);
        add(nameTextField);
        y += gap;

        JLabel fname = new JLabel("Father's Name:");
        fname.setBounds(labelX, y, 150, height);
        add(fname);

        fnameTextField = new JTextField();
        fnameTextField.setBounds(fieldX, y, width, height);
        add(fnameTextField);
        y += gap;

        JLabel dob = new JLabel("Date of Birth:");
        dob.setBounds(labelX, y, 150, height);
        add(dob);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(fieldX, y, width, height);
        dateChooser.setForeground(new Color(105, 105, 105));
        add(dateChooser);
        y += gap;

        JLabel gender = new JLabel("Gender:");
        gender.setBounds(labelX, y, 150, height);
        add(gender);

        male = new JRadioButton("Male");
        male.setBounds(fieldX, y, 70, height);
        male.setBackground(Color.WHITE);
        add(male);

        female = new JRadioButton("Female");
        female.setBounds(fieldX + 80, y, 80, height);
        female.setBackground(Color.WHITE);
        add(female);

        ButtonGroup gendergroup = new ButtonGroup();
        gendergroup.add(male);
        gendergroup.add(female);
        y += gap;

        JLabel marital = new JLabel("Marital Status:");
        marital.setBounds(labelX, y, 150, height);
        add(marital);

        married = new JRadioButton("Married");
        married.setBounds(fieldX, y, 80, height);
        married.setBackground(Color.WHITE);
        add(married);

        single = new JRadioButton("Single");
        single.setBounds(fieldX + 90, y, 70, height);
        single.setBackground(Color.WHITE);
        add(single);

        other = new JRadioButton("Other");
        other.setBounds(fieldX + 170, y, 70, height);
        other.setBackground(Color.WHITE);
        add(other);

        ButtonGroup maritalgroup = new ButtonGroup();
        maritalgroup.add(married);
        maritalgroup.add(single);
        maritalgroup.add(other);
        y += gap;

        JLabel email = new JLabel("Email:");
        email.setBounds(labelX, y, 150, height);
        add(email);

        emailTextField = new JTextField();
        emailTextField.setBounds(fieldX, y, width, height);
        add(emailTextField);
        y += gap;

        JLabel address = new JLabel("Address:");
        address.setBounds(labelX, y, 150, height);
        add(address);

        addressTextField = new JTextField();
        addressTextField.setBounds(fieldX, y, width, height);
        add(addressTextField);
        y += gap;

        JLabel city = new JLabel("City:");
        city.setBounds(labelX, y, 150, height);
        add(city);

        cityTextField = new JTextField();
        cityTextField.setBounds(fieldX, y, width, height);
        add(cityTextField);
        y += gap;

        JLabel state = new JLabel("State:");
        state.setBounds(labelX, y, 150, height);
        add(state);

        stateTextField = new JTextField();
        stateTextField.setBounds(fieldX, y, width, height);
        add(stateTextField);
        y += gap;

        JLabel pincode = new JLabel("Pin Code:");
        pincode.setBounds(labelX, y, 150, height);
        add(pincode);

        pincodeTextField = new JTextField();
        pincodeTextField.setBounds(fieldX, y, width, height);
        add(pincodeTextField);
        y += gap;

        JButton next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway", Font.BOLD, 12));
        next.setBounds(fieldX + 100, y, 100, 30);
        next.addActionListener(this);
        add(next);

        getContentPane().setBackground(Color.WHITE);
        setSize(800, 600);
        setLocation(350, 80);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String formno = "" + random;
        String name = nameTextField.getText();
        String fname = fnameTextField.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        if (male.isSelected()) gender = "Male";
        else if (female.isSelected()) gender = "Female";
        String email = emailTextField.getText();
        String martial = null;
        if (married.isSelected()) martial = "Married";
        else if (single.isSelected()) martial = "Single";
        else if (other.isSelected()) martial = "Other";
        String address = addressTextField.getText();
        String city = cityTextField.getText();
        String state = stateTextField.getText();
        String pin = pincodeTextField.getText();

        try {
            if (name.equals("")) {
                JOptionPane.showMessageDialog(null, "Name is Required");
            } else {
                DBConnection c = new DBConnection();
                String query = "INSERT INTO signup (formno, name, fname, dob, gender, email, marital, address, city, pincode, state) " +
               "VALUES('" + formno + "', '" + name + "', '" + fname + "', '" + dob + "', '" + gender + "', '" + email + "', '" + martial + "', '" + address + "', '" + city + "', '" + pin + "', '" + state + "')";

                c.s.executeUpdate(query);
                setVisible(false);
                new Additionaldetails(formno).setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        new Personaldetails();
    }
}
