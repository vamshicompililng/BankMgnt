package Bank_mgmt.ui;

import Bank_mgmt.db.DBConnection;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Accountdetails extends JFrame implements ActionListener {
    JLabel l1, l2, l3;
    JRadioButton r1, r2, r3, r4;
    JCheckBox c1, c2, c3, c4, c5, c6, c7;
    JButton b;
    String formno, aadhar, pan;

    Accountdetails(String formno, String aadhar, String pan) {
        this.formno = formno;
        this.aadhar = aadhar;
        this.pan = pan;

        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 3");

        l1 = new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));

        l2 = new JLabel("Account Type:");
        l2.setFont(new Font("Raleway", Font.BOLD, 18));

        r1 = new JRadioButton("Saving Account");
        r2 = new JRadioButton("Fixed Deposit Account");
        r3 = new JRadioButton("Current Account");
        r4 = new JRadioButton("Recurring Deposit Account");

        ButtonGroup groupAccount = new ButtonGroup();
        groupAccount.add(r1);
        groupAccount.add(r2);
        groupAccount.add(r3);
        groupAccount.add(r4);

        l3 = new JLabel("Services Required:");
        l3.setFont(new Font("Raleway", Font.BOLD, 18));

        c1 = new JCheckBox("ATM Card");
        c2 = new JCheckBox("Internet Banking");
        c3 = new JCheckBox("Mobile Banking");
        c4 = new JCheckBox("EMAIL Alerts");
        c5 = new JCheckBox("Cheque Book");
        c6 = new JCheckBox("E-Statement");
        c7 = new JCheckBox("I hereby declare that the above entered details are correct to the best of my knowledge.");

        b = new JButton("Submit");
        b.addActionListener(this);

        setLayout(null);

        l1.setBounds(280, 30, 600, 40);
        add(l1);

        l2.setBounds(100, 100, 200, 30);
        add(l2);

        r1.setBounds(100, 140, 200, 30);
        add(r1);

        r2.setBounds(350, 140, 250, 30);
        add(r2);

        r3.setBounds(100, 180, 200, 30);
        add(r3);

        r4.setBounds(350, 180, 250, 30);
        add(r4);

        l3.setBounds(100, 240, 200, 30);
        add(l3);

        c1.setBounds(100, 280, 200, 30);
        add(c1);

        c2.setBounds(350, 280, 200, 30);
        add(c2);

        c3.setBounds(100, 320, 200, 30);
        add(c3);

        c4.setBounds(350, 320, 200, 30);
        add(c4);

        c5.setBounds(100, 360, 200, 30);
        add(c5);

        c6.setBounds(350, 360, 200, 30);
        add(c6);

        c7.setBounds(100, 400, 600, 30);
        add(c7);

        b.setBounds(250, 460, 100, 30);
        add(b);

        getContentPane().setBackground(Color.WHITE);

        setSize(700, 600);
        setLocation(500, 120);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String accountType = null;
        if (r1.isSelected()) accountType = "Saving Account";
        else if (r2.isSelected()) accountType = "Fixed Deposit Account";
        else if (r3.isSelected()) accountType = "Current Account";
        else if (r4.isSelected()) accountType = "Recurring Deposit Account";

        String services = "";
        if (c1.isSelected()) services += "ATM Card ";
        if (c2.isSelected()) services += "Internet Banking ";
        if (c3.isSelected()) services += "Mobile Banking ";
        if (c4.isSelected()) services += "EMAIL Alerts ";
        if (c5.isSelected()) services += "Cheque Book ";
        if (c6.isSelected()) services += "E-Statement ";

        if (!c7.isSelected()) {
            JOptionPane.showMessageDialog(null, "Please confirm the declaration");
            return;
        }

        try {
            DBConnection conn = new DBConnection();

            // Insert into signup3 table
            String query = "INSERT INTO signup3 (formno, account_type, services) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.c.prepareStatement(query);
            ps.setString(1, formno);
            ps.setString(2, accountType);
            ps.setString(3, services);
            ps.executeUpdate();

            // Insert into signup_requests table
            String reqQuery = "INSERT INTO signup_requests (formno, aadhar, pan) VALUES (?, ?, ?)";
            PreparedStatement reqPs = conn.c.prepareStatement(reqQuery);
            reqPs.setString(1, formno);
            reqPs.setString(2, aadhar);
            reqPs.setString(3, pan);
            reqPs.executeUpdate();

            setVisible(false);
            new Accountapproval().setVisible(true);  // ✅ call no-arg constructor

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

