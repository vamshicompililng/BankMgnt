package Bank_mgmt.ui;

import Bank_mgmt.ui.Transactions;
import Bank_mgmt.db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class Bankdeposit extends JFrame implements ActionListener {

    JTextField t1;
    JButton b1, b2;
    JLabel l1;
    String pin;
    String userType;

    public Bankdeposit(String pin, String userType) {
        this.pin = pin;
        this.userType = userType;

        setLayout(null);

        ImageIcon i1 = new ImageIcon(getClass().getResource("/icons/atm.jpg"));

        Image i2 = i1.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel background = new JLabel(i3);
        background.setBounds(0, 0, 800, 600);
        add(background);

        l1 = new JLabel("ENTER AMOUNT YOU WANT TO DEPOSIT");
        l1.setFont(new Font("System", Font.BOLD, 16));
        l1.setForeground(Color.WHITE);
        l1.setBounds(140, 220, 400, 30);
        background.add(l1);

        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 22));
        t1.setBounds(160, 260, 300, 25);
        background.add(t1);

        b1 = new JButton("DEPOSIT");
        b1.setBounds(160, 300, 130, 30);
        background.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(330, 300, 130, 30);
        background.add(b2);

        b1.addActionListener(this);
        b2.addActionListener(this);

        setSize(800, 600);
        setLocation(400, 100);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String amount = t1.getText().trim();
            Date date = new Date();

            if (ae.getSource() == b1) {
                if (amount.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter the amount to deposit");
                } else {
                    DBConnection c1 = new DBConnection();
                    String query = "INSERT INTO bank (pin, date, type, amount) VALUES (?, ?, ?, ?)";
                    PreparedStatement ps = c1.c.prepareStatement(query);
                    ps.setString(1, pin);
                    ps.setTimestamp(2, new java.sql.Timestamp(date.getTime()));
                    ps.setString(3, "Deposit");
                    ps.setString(4, amount);
                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Rs. " + amount + " Deposited Successfully");
                    setVisible(false);
                    new Transactions(pin, userType).setVisible(true); // pass userType here
                }
            } else if (ae.getSource() == b2) {
                setVisible(false);
                new Transactions(pin, userType).setVisible(true); // also pass here
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    //public static void main(String[] args) {
       // new Deposit("1234", "Customer").setVisible(true);
   // }
}
