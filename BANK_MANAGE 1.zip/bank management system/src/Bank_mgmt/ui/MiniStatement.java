package Bank_mgmt.ui;

import Bank_mgmt.util.EmailComposer;
import Bank_mgmt.db.DBConnection;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.io.*;

public class MiniStatement extends JFrame implements ActionListener {

    JButton exitButton, downloadButton, shareButton;
    JLabel headingLabel, transactionLabel, cardLabel, balanceLabel;
    String pin;
    String filePath = null;

    MiniStatement(String pin) {
        super("Mini Statement");
        this.pin = pin;

        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setSize(400, 600);
        setLocation(100, 50);

        headingLabel = new JLabel("Indian Bank");
        headingLabel.setFont(new Font("System", Font.BOLD, 16));
        headingLabel.setBounds(150, 20, 200, 20);
        add(headingLabel);

        cardLabel = new JLabel();
        cardLabel.setFont(new Font("System", Font.PLAIN, 12));
        cardLabel.setBounds(20, 60, 360, 20);
        add(cardLabel);

        transactionLabel = new JLabel();
        transactionLabel.setFont(new Font("Monospaced", Font.PLAIN, 12));
        transactionLabel.setBounds(20, 100, 360, 300);
        add(transactionLabel);

        balanceLabel = new JLabel();
        balanceLabel.setFont(new Font("System", Font.BOLD, 12));
        balanceLabel.setBounds(20, 420, 300, 20);
        add(balanceLabel);

        exitButton = new JButton("Exit");
        exitButton.setBounds(40, 470, 100, 30);
        exitButton.addActionListener(this);
        add(exitButton);

        downloadButton = new JButton("Download");
        downloadButton.setBounds(150, 470, 100, 30);
        downloadButton.addActionListener(this);
        add(downloadButton);

        shareButton = new JButton("Share");
        shareButton.setBounds(260, 470, 100, 30);
        shareButton.addActionListener(this);
        add(shareButton);

        displayCardNumber();
        displayTransactions();
    }

    void displayCardNumber() {
        try {
            DBConnection c = new DBConnection();
            ResultSet rs = c.s.executeQuery("select card_number from login where pin = '" + pin + "'");
            if (rs.next()) {
                String card = rs.getString("card_number");
                cardLabel.setText("Card Number: " + card.substring(0, 4) + "XXXXXXXX" + card.substring(12));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void displayTransactions() {
        try {
            int balance = 0;
            StringBuilder html = new StringBuilder("<html>");
            html.append(String.format("%-20s %-10s %s<br><br>", "Date", "Type", "Amount"));

            DBConnection c1 = new DBConnection();
            ResultSet rs = c1.s.executeQuery("SELECT * FROM bank WHERE pin = '" + pin + "'");
            while (rs.next()) {
                String date = rs.getString("date");
                String type = rs.getString("type");
                String amount = rs.getString("amount");

                html.append(String.format("%-20s %-10s %s<br>", date, type, amount));

                if (type.equalsIgnoreCase("Deposit")) {
                    balance += Integer.parseInt(amount);
                } else {
                    balance -= Integer.parseInt(amount);
                }
            }
            html.append("</html>");
            transactionLabel.setText(html.toString());
            balanceLabel.setText("Your Total Balance is Rs " + balance);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == exitButton) {
            this.setVisible(false);
        } else if (ae.getSource() == downloadButton) {
            try {
                String fileName = "MiniStatement_" + System.currentTimeMillis() + ".txt";
                filePath = "C:\\Users\\Public\\" + fileName;
                FileWriter fw = new FileWriter(filePath);

                fw.write("Date\t\tType\tAmount\n");

                DBConnection c = new DBConnection();
                ResultSet rs = c.s.executeQuery("SELECT * FROM bank WHERE pin = '" + pin + "'");
                int balance = 0;
                while (rs.next()) {
                    String date = rs.getString("date");
                    String type = rs.getString("type");
                    String amount = rs.getString("amount");
                    fw.write(date + "\t" + type + "\t" + amount + "\n");

                    if (type.equalsIgnoreCase("Deposit")) {
                        balance += Integer.parseInt(amount);
                    } else {
                        balance -= Integer.parseInt(amount);
                    }
                }
                fw.write("\nTotal Balance: Rs " + balance);
                fw.close();

                JOptionPane.showMessageDialog(null, "Statement saved successfully at:\n" + filePath);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to download statement:\n" + ex.getMessage());
            }
        } else if (ae.getSource() == shareButton) {
            if (filePath == null) {
                JOptionPane.showMessageDialog(null, "Please download the statement before sharing.");
                return;
            }
            new EmailComposer(filePath).setVisible(true);
        }
    }

    public static void main(String[] args) {
        new MiniStatement("1234").setVisible(true);
    }
}
