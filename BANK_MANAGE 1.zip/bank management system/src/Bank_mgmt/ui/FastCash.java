package Bank_mgmt.ui;

import Bank_mgmt.ui.Transactions;
import Bank_mgmt.db.DBConnection;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.Date;
import java.text.SimpleDateFormat;

public class FastCash extends JFrame implements ActionListener {

    JLabel l1;
    JButton b1, b2, b3, b4, b5, b6, b7;
    String pin, userType;

    public FastCash(String pin, String userType) {
        this.pin = pin;
        this.userType = userType;

        ImageIcon i1 = new ImageIcon(getClass().getResource("/icons/atm.jpg"));

        Image i2 = i1.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 800, 600);
        add(l3);

        l1 = new JLabel("SELECT WITHDRAWAL AMOUNT");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));
        l1.setBounds(200, 170, 400, 35);
        l3.add(l1);

        b1 = new JButton("Rs 100");
        b2 = new JButton("Rs 500");
        b3 = new JButton("Rs 1000");
        b4 = new JButton("Rs 2000");
        b5 = new JButton("Rs 5000");
        b6 = new JButton("Rs 10000");
        b7 = new JButton("BACK");

        int x1 = 160, x2 = 340, y = 220, width = 120, height = 28, gap = 38;

        b1.setBounds(x1, y, width, height);
        b2.setBounds(x2, y, width, height);
        b3.setBounds(x1, y + gap, width, height);
        b4.setBounds(x2, y + gap, width, height);
        b5.setBounds(x1, y + 2 * gap, width, height);
        b6.setBounds(x2, y + 2 * gap, width, height);
        b7.setBounds(x2, y + 3 * gap, width, height);

        l3.add(b1); l3.add(b2); l3.add(b3); l3.add(b4); l3.add(b5); l3.add(b6); l3.add(b7);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);

        setLayout(null);
        setSize(800, 600);
        setLocation(400, 100);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == b7) {
                setVisible(false);
                new Transactions(pin, userType).setVisible(true);
                return;
            }

            String text = ((JButton) ae.getSource()).getText(); // "Rs 2000"
            String amount = text.replaceAll("[^0-9]", "");      // "2000"

            DBConnection c = new DBConnection();
            ResultSet rs = c.s.executeQuery("select * from bank where pin = '" + pin + "'");
            int balance = 0;
            while (rs.next()) {
                if (rs.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(rs.getString("amount"));
                } else {
                    balance -= Integer.parseInt(rs.getString("amount"));
                }
            }

            if (balance < Integer.parseInt(amount)) {
                JOptionPane.showMessageDialog(null, "Insufficient Balance");
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String date = sdf.format(new Date());

            c.s.executeUpdate("insert into bank values('" + pin + "', '" + date + "', 'Withdrawl', '" + amount + "')");
            JOptionPane.showMessageDialog(null, "Rs. " + amount + " Debited Successfully");

            setVisible(false);
            new Transactions(pin, userType).setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //public static void main(String[] args) {
        //new FastCash("1234", "Customer").setVisible(true);
    //}
}
