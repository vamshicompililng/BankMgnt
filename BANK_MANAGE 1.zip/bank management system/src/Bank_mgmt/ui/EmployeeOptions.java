package Bank_mgmt.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EmployeeOptions extends JFrame implements ActionListener {
    JButton approvalBtn;
    String pin;
    String userType;

    // Constructor with pin and userType
    public EmployeeOptions(String pin, String userType) {
        this.pin = pin;
        this.userType = userType;

        setTitle("Employee Panel");
        setSize(400, 200);
        setLayout(new GridLayout(2, 1, 10, 10));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label = new JLabel("Welcome Employee", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        add(label);

        approvalBtn = new JButton("Approve/Reject Customer Requests");
        approvalBtn.addActionListener(this);
        add(approvalBtn);

        getContentPane().setBackground(Color.WHITE);
    }

    // Optional default constructor
    public EmployeeOptions() {
        this("", "Employee");
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == approvalBtn) {
            setVisible(false);
            new EmployeeApprovalDashboard().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new EmployeeOptions("1234", "Employee").setVisible(true);  // Test entry
    }
}

