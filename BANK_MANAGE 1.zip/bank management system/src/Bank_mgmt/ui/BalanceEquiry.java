package Bank_mgmt.ui;

import Bank_mgmt.ui.Transactions;
import Bank_mgmt.db.DBConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import javax.swing.*;

class BalanceEquiry extends JFrame implements ActionListener {

    JButton back;
    JLabel balanceLabel;
    String pin;

    BalanceEquiry(String pin) {
        this.pin = pin;

        ImageIcon i1 = new ImageIcon(getClass().getResource("/icons/atm.jpg"));

        Image i2 = i1.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel background = new JLabel(i3);
        background.setBounds(0, 0, 800, 600);
        add(background);

        setLayout(null);

        balanceLabel = new JLabel();
        balanceLabel.setForeground(Color.WHITE);
        balanceLabel.setFont(new Font("System", Font.BOLD, 16));
        balanceLabel.setBounds(140, 230, 500, 35);
        background.add(balanceLabel);

        back = new JButton("BACK");
        back.setBounds(250, 320, 140, 35);
        background.add(back);
        back.addActionListener(this);

        int balance = 0;
        try {
            DBConnection c1 = new DBConnection();
            ResultSet rs = c1.s.executeQuery("SELECT * FROM bank WHERE pin = '" + pin + "'");
            while (rs.next()) {
                if (rs.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(rs.getString("amount"));
                } else {
                    balance -= Integer.parseInt(rs.getString("amount"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        balanceLabel.setText("Your Current Account Balance is Rs " + balance);

        setSize(800, 600);
        setUndecorated(true);
        setLocation(400, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Transactions(pin, "Customer").setVisible(true); // Updated to fix the error
    }

    public static void main(String[] args) {
        new BalanceEquiry("").setVisible(true);
    }
}
