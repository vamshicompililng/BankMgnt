package Bank_mgmt.ui;

import Bank_mgmt.ui.Accountapproval;
import Bank_mgmt.db.DBConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class EmployeeApprovalDashboard extends JFrame {
    JTable table;
    DefaultTableModel model;

    public EmployeeApprovalDashboard() {
        setTitle("Pending Signup Requests");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel header = new JLabel("Select a row to Approve or Reject", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 16));
        add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Form No", "Name", "Email", "PAN", "Aadhar", "DOB"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadPendingRequests();

        JPanel buttonPanel = new JPanel();
        JButton approveButton = new JButton("Approve Selected");
        JButton rejectButton = new JButton("Reject Selected");
        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        add(buttonPanel, BorderLayout.SOUTH);

        approveButton.addActionListener(e -> {
            if (table.isEditing()) table.getCellEditor().stopCellEditing();
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row.");
                return;
            }
            String formno = table.getValueAt(row, 0).toString();
            handleApproval(formno, row);
        });

        rejectButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row to reject.");
                return;
            }
            String formno = table.getValueAt(row, 0).toString();
            String reason = JOptionPane.showInputDialog(this, "Enter reason for rejection:");
            if (reason == null || reason.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Rejection reason is required.");
                return;
            }
            try {
                DBConnection c = new DBConnection();
                Accountapproval.approvalStatus = "REJECTED";
                Accountapproval.rejectionReason = reason;
                c.s.executeUpdate("UPDATE signup_requests SET status='DENIED' WHERE formno='" + formno + "'");
                JOptionPane.showMessageDialog(this, "Request denied.");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Rejection failed: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
    }

    private void loadPendingRequests() {
        model.setRowCount(0);
        try {
            DBConnection c = new DBConnection();
            ResultSet rs = c.s.executeQuery("SELECT sr.formno, s.name, s.email, s2.pan, s2.aadhar, s.dob FROM signup_requests sr JOIN signup s ON sr.formno = s.formno JOIN signup2 s2 ON sr.formno = s2.formno WHERE sr.status = 'PENDING'");
            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("formno"), rs.getString("name"), rs.getString("email"), rs.getString("pan"), rs.getString("aadhar"), rs.getString("dob")});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void handleApproval(String formno, int row) {
        try {
            DBConnection c = new DBConnection();

            String email = table.getValueAt(row, 2).toString();
            String pan = table.getValueAt(row, 3).toString();
            String aadhar = table.getValueAt(row, 4).toString();
            String dob = table.getValueAt(row, 5).toString();

            StringBuilder reasons = new StringBuilder();

            if (!pan.matches("[A-Z]{5}[0-9]{4}[A-Z]")) reasons.append("Invalid PAN format\n");
            if (!aadhar.matches("\\d{12}")) reasons.append("Aadhar must be 12 digits\n");

            ResultSet rs = c.s.executeQuery("SELECT * FROM login WHERE formno = '" + formno + "'");
            if (rs.next()) reasons.append("Customer already approved\n");

            LocalDate birthDate = LocalDate.parse(dob, DateTimeFormatter.ofPattern("MMM d, yyyy"));
            int age = Period.between(birthDate, LocalDate.now()).getYears();
            if (age < 18) reasons.append("Customer must be at least 18 years old\n");

            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$") || email.toLowerCase().contains("test") || email.endsWith("@abc.com") || email.endsWith("@xyz.com")) {
                reasons.append("Invalid or suspicious email\n");
            }

            if (reasons.length() > 0) {
                JOptionPane.showMessageDialog(this, "Cannot approve due to:\n" + reasons);
                return;
            }

            String card = "" + Math.abs((long)(Math.random() * 10000000000000000L));
            String pin = "" + (1000 + new java.util.Random().nextInt(9000));

            c.s.executeUpdate("UPDATE signup_requests SET status='APPROVED' WHERE formno='" + formno + "'");
            c.s.executeUpdate("INSERT INTO login (formno, card_number, pin, aadhar, usertype) VALUES ('" + formno + "', '" + card + "', '" + pin + "', '" + aadhar + "', 'Customer')");

            Accountapproval.approvalStatus = "APPROVED";
            Accountapproval.cardGenerated = card;
            Accountapproval.pinGenerated = pin;

            JOptionPane.showMessageDialog(this, "Approved. Card No and PIN generated for customer.");
            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Approval failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new EmployeeApprovalDashboard().setVisible(true);
    }
}

