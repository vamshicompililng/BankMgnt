package Bank_mgmt.ui;

import Bank_mgmt.db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Additionaldetails extends JFrame implements ActionListener {

    JComboBox religion, category, income, education, occupation;
    JTextField panField, aadharField;
    JRadioButton rb1, rb2, rb3, rb4;
    JButton next;
    String formno;

    Additionaldetails(String formno) {
        this.formno = formno;

        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");
        setLayout(null);

        JLabel l1 = new JLabel("Page 2: Additional Details");
        l1.setFont(new Font("Raleway", Font.BOLD, 20));
        l1.setBounds(250, 20, 400, 30);
        add(l1);

        JLabel l2 = new JLabel("Religion:");
        l2.setFont(new Font("Raleway", Font.BOLD, 16));
        l2.setBounds(100, 80, 100, 30);
        add(l2);

        String[] valReligion = {"Hindu", "Muslim", "Christian", "Sikh", "Other"};
        religion = new JComboBox(valReligion);
        religion.setBounds(300, 80, 200, 30);
        add(religion);

        JLabel l3 = new JLabel("Category:");
        l3.setFont(new Font("Raleway", Font.BOLD, 16));
        l3.setBounds(100, 120, 100, 30);
        add(l3);

        String[] valCategory = {"General", "OBC", "SC", "ST", "Other"};
        category = new JComboBox(valCategory);
        category.setBounds(300, 120, 200, 30);
        add(category);

        JLabel l4 = new JLabel("Income:");
        l4.setFont(new Font("Raleway", Font.BOLD, 16));
        l4.setBounds(100, 160, 100, 30);
        add(l4);

        String[] incomeValues = {"Null", "<1,50,000", "<2,50,000", "<5,00,000", "Upto 10,00,000"};
        income = new JComboBox(incomeValues);
        income.setBounds(300, 160, 200, 30);
        add(income);

        JLabel l5 = new JLabel("Educational Qualification:");
        l5.setFont(new Font("Raleway", Font.BOLD, 16));
        l5.setBounds(100, 200, 200, 30);
        add(l5);

        String[] educationValues = {"Non-Graduate", "Graduate", "Post-Graduate", "Doctrate", "Others"};
        education = new JComboBox(educationValues);
        education.setBounds(300, 200, 200, 30);
        add(education);

        JLabel l6 = new JLabel("Occupation:");
        l6.setFont(new Font("Raleway", Font.BOLD, 16));
        l6.setBounds(100, 240, 100, 30);
        add(l6);

        String[] occupationValues = {"Salaried", "Self-Employed", "Business", "Student", "Retired", "Others"};
        occupation = new JComboBox(occupationValues);
        occupation.setBounds(300, 240, 200, 30);
        add(occupation);

        JLabel l7 = new JLabel("PAN Number:");
        l7.setFont(new Font("Raleway", Font.BOLD, 16));
        l7.setBounds(100, 280, 200, 30);
        add(l7);

        panField = new JTextField();
        panField.setBounds(300, 280, 200, 30);
        add(panField);

        JLabel l8 = new JLabel("Aadhar Number:");
        l8.setFont(new Font("Raleway", Font.BOLD, 16));
        l8.setBounds(100, 320, 200, 30);
        add(l8);

        aadharField = new JTextField();
        aadharField.setBounds(300, 320, 200, 30);
        add(aadharField);

        JLabel l9 = new JLabel("Senior Citizen:");
        l9.setFont(new Font("Raleway", Font.BOLD, 16));
        l9.setBounds(100, 360, 200, 30);
        add(l9);

        rb1 = new JRadioButton("Yes");
        rb1.setBounds(300, 360, 80, 30);
        add(rb1);

        rb2 = new JRadioButton("No");
        rb2.setBounds(400, 360, 80, 30);
        add(rb2);

        ButtonGroup group1 = new ButtonGroup();
        group1.add(rb1);
        group1.add(rb2);

        JLabel l10 = new JLabel("Existing Account:");
        l10.setFont(new Font("Raleway", Font.BOLD, 16));
        l10.setBounds(100, 400, 200, 30);
        add(l10);

        rb3 = new JRadioButton("Yes");
        rb3.setBounds(300, 400, 80, 30);
        add(rb3);

        rb4 = new JRadioButton("No");
        rb4.setBounds(400, 400, 80, 30);
        add(rb4);

        ButtonGroup group2 = new ButtonGroup();
        group2.add(rb3);
        group2.add(rb4);

        next = new JButton("Next");
        next.setBounds(300, 460, 100, 30);
        next.addActionListener(this);
        add(next);

        setSize(650, 600);
        setLocation(400, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String sreligion = (String) religion.getSelectedItem();
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String seducation = (String) education.getSelectedItem();
        String soccupation = (String) occupation.getSelectedItem();
        String span = panField.getText().trim();
        String saadhar = aadharField.getText().trim();

        String scitizen = rb1.isSelected() ? "Yes" : rb2.isSelected() ? "No" : "";
        String seaccount = rb3.isSelected() ? "Yes" : rb4.isSelected() ? "No" : "";

        if (span.equals("") || saadhar.equals("")) {
            JOptionPane.showMessageDialog(null, "PAN and Aadhar are required");
            return;
        }

        // Validate PAN: 10 alphanumeric characters
        if (span.length() != 10 || !span.matches("[A-Za-z0-9]+")) {
            JOptionPane.showMessageDialog(null, "Invalid PAN. It must be 10 alphanumeric characters.");
            return;
        }

        // Validate Aadhar: 12 digit numeric
        if (saadhar.length() != 12 || !saadhar.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "Invalid Aadhar. It must be 12 digits.");
            return;
        }

        try {
            DBConnection c = new DBConnection();
            String query = "INSERT INTO signup2 (formno, religion, category, income, education, occupation, pan, aadhar, scitizen, eaccount) " +
                    "VALUES ('" + formno + "', '" + sreligion + "', '" + scategory + "', '" + sincome + "', '" + seducation + "', '" + soccupation + "', '" + span + "', '" + saadhar + "', '" + scitizen + "', '" + seaccount + "')";
            c.s.executeUpdate(query);

            setVisible(false);
            new Accountdetails(formno, saadhar, span).setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Additionaldetails("");
    }
}
