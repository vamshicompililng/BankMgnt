package Bank_mgmt.ui;

import Bank_mgmt.db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeLogin extends JFrame implements ActionListener {
    JTextField cardField;
    JPasswordField pinField;
    JButton loginButton;

    public EmployeeLogin() {
        setTitle("Employee Login");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel l1 = new JLabel("Employee Card Number:");
        l1.setBounds(50, 50, 200, 25);
        add(l1);

        cardField = new JTextField();
        cardField.setBounds(200, 50, 130, 25);
        add(cardField);

        JLabel l2 = new JLabel("PIN:");
        l2.setBounds(50, 100, 100, 25);
        add(l2);

        pinField = new JPasswordField();
        pinField.setBounds(200, 100, 130, 25);
        add(pinField);

        loginButton = new JButton("Login");
        loginButton.setBounds(130, 150, 100, 30);
        loginButton.addActionListener(this);
        add(loginButton);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
    }

    public void actionPerformed(ActionEvent ae) {
        String card = cardField.getText().trim();
        String pin = new String(pinField.getPassword()).trim();

        try {
            DBConnection c = new DBConnection();
            String query = "SELECT * FROM login WHERE card_number = ? AND pin = ? AND usertype = 'Employee'";
            PreparedStatement ps = c.c.prepareStatement(query);
            ps.setString(1, card);
            ps.setString(2, pin);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                setVisible(false);
                new EmployeeOptions(pin, "Employee").setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Credentials or Not an Employee");
            }

            rs.close();
            ps.close();
            c.c.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new EmployeeLogin().setVisible(true);
    }
}

