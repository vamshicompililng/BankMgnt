package Bank_mgmt.ui;

import Bank_mgmt.ui.Transactions;
import Bank_mgmt.db.DBConnection;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Pin extends JFrame implements ActionListener {

    JPasswordField oldPinField, newPinField, reEnterField;
    JButton b1, b2;
    JLabel l1, l2, l3, l4;
    String pin, userType;

    public Pin(String pin, String userType) {
        this.pin = pin;
        this.userType = userType;

        ImageIcon i1 = new ImageIcon(getClass().getResource("/icons/atm.jpg"));

        Image i2 = i1.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel background = new JLabel(i3);
        background.setBounds(0, 0, 800, 600);
        add(background);

        l1 = new JLabel("CHANGE YOUR PIN");
        l1.setFont(new Font("System", Font.BOLD, 16));
        l1.setForeground(Color.WHITE);
        l1.setBounds(250, 150, 400, 30);
        background.add(l1);

        l4 = new JLabel("Current PIN:");
        l4.setFont(new Font("System", Font.BOLD, 16));
        l4.setForeground(Color.WHITE);
        l4.setBounds(140, 190, 150, 25);
        background.add(l4);

        l2 = new JLabel("New PIN:");
        l2.setFont(new Font("System", Font.BOLD, 16));
        l2.setForeground(Color.WHITE);
        l2.setBounds(140, 230, 150, 25);
        background.add(l2);

        l3 = new JLabel("Re-Enter New PIN:");
        l3.setFont(new Font("System", Font.BOLD, 16));
        l3.setForeground(Color.WHITE);
        l3.setBounds(140, 270, 180, 25);
        background.add(l3);

        oldPinField = new JPasswordField();
        oldPinField.setFont(new Font("Raleway", Font.BOLD, 18));
        oldPinField.setBounds(310, 190, 130, 25);
        background.add(oldPinField);

        newPinField = new JPasswordField();
        newPinField.setFont(new Font("Raleway", Font.BOLD, 18));
        newPinField.setBounds(310, 230, 130, 25);
        background.add(newPinField);

        reEnterField = new JPasswordField();
        reEnterField.setFont(new Font("Raleway", Font.BOLD, 18));
        reEnterField.setBounds(310, 270, 130, 25);
        background.add(reEnterField);

        b1 = new JButton("CHANGE");
        b1.setBounds(190, 320, 120, 30);
        b1.addActionListener(this);
        background.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(320, 320, 120, 30);
        b2.addActionListener(this);
        background.add(b2);

        setLayout(null);
        setSize(800, 600);
        setLocation(400, 100);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String oldPin = oldPinField.getText();
        String newPin = newPinField.getText();
        String rePin = reEnterField.getText();

        if (ae.getSource() == b1) {
            if (oldPin.isEmpty() || newPin.isEmpty() || rePin.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields");
                return;
            }

            if (!newPin.equals(rePin)) {
                JOptionPane.showMessageDialog(this, "New PIN entries do not match");
                return;
            }

            try {
                DBConnection c = new DBConnection();
                ResultSet rs = c.s.executeQuery("SELECT * FROM login WHERE pin = '" + oldPin + "'");
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this, "Current PIN is incorrect");
                    return;
                }

                c.s.executeUpdate("UPDATE bank SET pin = '" + newPin + "' WHERE pin = '" + oldPin + "'");
                c.s.executeUpdate("UPDATE login SET pin = '" + newPin + "' WHERE pin = '" + oldPin + "'");
                c.s.executeUpdate("UPDATE signup3 SET pin = '" + newPin + "' WHERE pin = '" + oldPin + "'");

                JOptionPane.showMessageDialog(this, "PIN changed successfully");
                setVisible(false);
                new Transactions(newPin, userType).setVisible(true);

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error occurred while changing PIN");
            }

        } else if (ae.getSource() == b2) {
            setVisible(false);
            new Transactions(pin, userType).setVisible(true);
        }
    }

    //public static void main(String[] args) {
        //new Pin("1234", "Customer").setVisible(true); // Sample run
    //}
}
