package Bank_mgmt.ui;

import Bank_mgmt.ui.Launcher;
import Bank_mgmt.ui.Login;
import javax.swing.*;
import java.awt.*;

public class Accountapproval extends JFrame {

    JLabel statusLabel;
    JButton loginButton;
    static String approvalStatus = "PENDING";
    static String cardGenerated = "";
    static String pinGenerated = "";
    static String rejectionReason = "";

    public Accountapproval() {
        setTitle("Waiting for Employee Approval..");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        statusLabel = new JLabel("Waiting for Employee Approval..", SwingConstants.CENTER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        add(statusLabel, BorderLayout.CENTER);

        loginButton = new JButton("Login");
        loginButton.setVisible(false);
        loginButton.addActionListener(e -> {
            setVisible(false);
            new Login().setVisible(true);
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loginButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);

        // ✅ Open MenuScreen ONCE after 3 seconds
        new javax.swing.Timer(3000, e -> {
            new Launcher().setVisible(true);
            ((Timer) e.getSource()).stop(); // ✅ Stop this timer to prevent repeated MenuScreen
            checkApprovalStatus();          // ✅ Begin status polling after menu is shown
        }).start();
    }

    private void checkApprovalStatus() {
        Timer statusCheck = new Timer(2000, e -> {
            if ("APPROVED".equals(approvalStatus)) {
                statusLabel.setText("<html>Approved!<br>Card No: " + cardGenerated + "<br>PIN: " + pinGenerated + "</html>");
                loginButton.setVisible(true);
                ((Timer) e.getSource()).stop();
            } else if ("REJECTED".equals(approvalStatus)) {
                statusLabel.setText("<html>Request Rejected.<br>Reason: " + rejectionReason.replaceAll("\n", "<br>") + "</html>");
                loginButton.setVisible(true);
                ((Timer) e.getSource()).stop();
            }
        });
        statusCheck.start();
    }

    public static void main(String[] args) {
        new Accountapproval().setVisible(true);
    }
}
