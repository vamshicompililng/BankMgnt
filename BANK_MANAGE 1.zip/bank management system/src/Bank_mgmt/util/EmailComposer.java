package Bank_mgmt.util;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

public class EmailComposer extends JFrame implements ActionListener {
    JTextField senderField, recipientField;
    JButton submitButton;
    String filePath;

    public EmailComposer(String filePath) {
        this.filePath = filePath;

        setTitle("Share Mini Statement");
        setSize(400, 250);
        setLocation(500, 300);
        setLayout(null);

        JLabel senderLabel = new JLabel("Enter your Gmail address:");
        senderLabel.setBounds(50, 20, 300, 25);
        add(senderLabel);

        senderField = new JTextField("sindhujabillakanti8@gmail.com");
        senderField.setBounds(50, 45, 300, 25);
        add(senderField);

        JLabel recipientLabel = new JLabel("Enter recipient email:");
        recipientLabel.setBounds(50, 75, 300, 25);
        add(recipientLabel);

        recipientField = new JTextField();
        recipientField.setBounds(50, 100, 300, 25);
        add(recipientField);

        submitButton = new JButton("Submit");
        submitButton.setBounds(140, 150, 100, 30);
        submitButton.addActionListener(this);
        add(submitButton);
    }

    public void actionPerformed(ActionEvent e) {
        String from = senderField.getText().trim();
        String to = recipientField.getText().trim();

        if (from.isEmpty() || to.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Both sender and recipient emails are required.");
            return;
        }

        JPasswordField passwordField = new JPasswordField();
        int option = JOptionPane.showConfirmDialog(this, passwordField, "Enter App Password:", JOptionPane.OK_CANCEL_OPTION);
        if (option != JOptionPane.OK_OPTION) return;

        String password = new String(passwordField.getPassword());

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            File file = new File(filePath);
            if (!file.exists()) {
                JOptionPane.showMessageDialog(this, "File does not exist: " + filePath);
                return;
            }

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("Your Mini Statement");

            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText("Please find attached your mini statement.");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            MimeBodyPart attachmentPart = new MimeBodyPart();
            DataSource source = new FileDataSource(file);
            attachmentPart.setDataHandler(new DataHandler(source));
            attachmentPart.setFileName(file.getName());
            multipart.addBodyPart(attachmentPart);

            message.setContent(multipart);
            Transport.send(message);

            JOptionPane.showMessageDialog(this, "Email sent successfully to: " + to);
            this.setVisible(false);

        } catch (Exception ex) {
            ex.printStackTrace(); // Show full stack trace in console
            JOptionPane.showMessageDialog(this, "Failed to send email:\n" + ex.toString());
        }
    }
}
